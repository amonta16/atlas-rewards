/**
 * FAQ content — CP-145. Six questions, short answers. Shared by the
 * accordion and the FAQPage JSON-LD. Keep answers to two sentences.
 */
export const FAQS: { q: string; a: string }[] = [
  {
    q: "Do my customers have to download an app?",
    a: "No. They scan the QR card at your counter and the app opens in their browser and saves to their home screen. There's also an iOS app in the App Store.",
  },
  {
    q: "Does it work with my point-of-sale?",
    a: "Yes, with any POS. Staff award points from a separate front-desk screen by scanning the customer's QR code or looking them up by phone number — nothing changes about how you ring people up.",
  },
  {
    q: "Is it really my brand?",
    a: "Your name, logo, colors, rewards and messages. Customers see your business, not Atlas.",
  },
  {
    q: "Do I need to be technical?",
    a: "No. We set everything up with you and hand you a simple dashboard. Most owners never touch a setting after launch.",
  },
  {
    q: "How long until it's live?",
    a: "Setup happens in one working session. You get a QR card and a join link, and customers can start earning that day.",
  },
  {
    q: "How do I know it's working?",
    a: "Your dashboard shows members, visits, redemptions and reviews, so you see the difference instead of guessing.",
  },
];
