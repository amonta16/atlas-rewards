import { Bell, Gift, MessageSquareHeart, Star, type LucideIcon } from "lucide-react";
import { Reveal } from "./reveal";

/**
 * Features — CP-145. Four cards, one sentence each. Everything else is a
 * single line underneath. (Replaces FeatureShowcase + RewardsDemo +
 * AnalyticsDemo + ProblemSection + BeforeAfter.)
 */
const FEATURES: Array<{ icon: LucideIcon; t: string; d: string }> = [
  { icon: Gift, t: "Points & rewards", d: "Every visit earns points. Points turn into free product, and free product turns into the next visit." },
  { icon: Bell, t: "Offers & push notifications", d: "Send a special to every customer's phone in one tap. No SMS fees, no email list." },
  { icon: MessageSquareHeart, t: "Win-backs & birthdays", d: "Customers who stop coming get a nudge with a reward attached — automatically." },
  { icon: Star, t: "Google reviews", d: "Ask for a review right after a good visit, and pay them in points when they leave one." },
];

export function Features() {
  return (
    <section className="lp-section" aria-labelledby="features-title">
      <div className="lp-container">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="lp-eyebrow justify-center">What it does</p>
          <h2 id="features-title" className="lp-h2 mt-4">Everything the big chains have. Nothing you have to run.</h2>
        </Reveal>

        <ul className="mt-12 grid gap-4 sm:grid-cols-2">
          {FEATURES.map(({ icon: I, t, d }, i) => (
            <Reveal as="li" key={t} delay={i * 70} className="lp-card p-6 sm:p-7">
              <span className="grid h-11 w-11 place-items-center rounded-xl bg-[#f3f7fb] text-[#1f5f8b]">
                <I className="h-5 w-5" aria-hidden />
              </span>
              <h3 className="mt-4 text-lg font-semibold text-[#14213d]">{t}</h3>
              <p className="mt-1.5 text-[15px] leading-relaxed text-slate-600">{d}</p>
            </Reveal>
          ))}
        </ul>

        <Reveal delay={300} className="mt-6 text-center text-sm text-slate-500">
          Also included: streaks, a prize wheel, referrals, memberships, a front-desk scanner and a results dashboard.
        </Reveal>
      </div>
    </section>
  );
}
