import { Cigarette, Gamepad2, Sparkles, UtensilsCrossed } from "lucide-react";
import { Reveal } from "./reveal";

/**
 * Niche strip — CP-145. Replaces the logo cloud (which was mostly
 * placeholders). Says who this is for in one glance.
 */
const NICHES = [
  { icon: Cigarette, label: "Smoke shops" },
  { icon: Sparkles, label: "Med spas" },
  { icon: UtensilsCrossed, label: "Food & drink" },
  { icon: Gamepad2, label: "Entertainment" },
];

export function NicheStrip() {
  return (
    <section className="py-12 md:py-16" aria-label="Who Atlas is for">
      <Reveal className="lp-container">
        <p className="text-center text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">Built for the places people visit every week</p>
        <ul className="mt-6 flex flex-wrap items-center justify-center gap-2 sm:gap-3">
          {NICHES.map(({ icon: I, label }) => (
            <li key={label} className="inline-flex h-11 items-center gap-2 rounded-full border border-[#e3e9f0] bg-white px-4 text-sm font-medium text-[#14213d]">
              <I className="h-4 w-4 text-[#1f5f8b]" aria-hidden />
              {label}
            </li>
          ))}
        </ul>
      </Reveal>
    </section>
  );
}
