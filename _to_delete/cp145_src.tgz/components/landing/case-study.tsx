import { MapPin } from "lucide-react";
import { ANCHORS } from "@/lib/landing/config";
import { Reveal } from "./reveal";
import { DemoCta } from "./cta-button";

/**
 * Case study — CP-145. Real launch photos (public/landing/exotic-*.jpg),
 * three short facts. No placeholder stats or quotes on a live page — add
 * real numbers to FACTS when the dashboard has them.
 */
const FACTS = ["Set up in one visit with the owner", "Banner at the door, QR card by the register", "$1 = 100 points, free products as rewards"];

export function CaseStudy() {
  return (
    <section id={ANCHORS.results} className="lp-section lp-tint scroll-mt-24" aria-labelledby="case-title">
      <div className="lp-container">
        <Reveal className="lp-card overflow-hidden">
          <div className="grid lg:grid-cols-2">
            <div className="relative min-h-[260px] sm:min-h-[340px]">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/landing/exotic-storefront.jpg"
                alt="The Atlas team with the owner of Exotic Smoke Shop next to the rewards banner at the shop entrance"
                width={1600}
                height={1200}
                loading="lazy"
                className="absolute inset-0 h-full w-full object-cover"
              />
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/landing/exotic-instore.jpg"
                alt="Inside Exotic Smoke Shop with the rewards banner by the register"
                width={1600}
                height={1200}
                loading="lazy"
                className="absolute bottom-4 right-4 hidden w-40 rotate-2 rounded-lg border-4 border-white object-cover shadow-xl sm:block lg:w-48"
              />
            </div>
            <div className="p-6 sm:p-8 lg:p-10">
              <p className="lp-eyebrow">
                <MapPin className="h-3.5 w-3.5" aria-hidden /> Live install
              </p>
              <h2 id="case-title" className="mt-3 text-2xl font-semibold tracking-tight text-[#14213d] sm:text-3xl">Exotic Smoke Shop, San Luis Obispo</h2>
              <ul className="mt-5 space-y-2.5 text-[15px] text-slate-600">
                {FACTS.map((f) => (
                  <li key={f} className="flex gap-2.5">
                    <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-[#1f5f8b]" aria-hidden />
                    {f}
                  </li>
                ))}
              </ul>
              <div className="mt-7">
                <DemoCta source="case_study" size="md">
                  Get set up like this
                </DemoCta>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
