"use client";
import { useEffect, useRef, useState, useTransition } from "react";
import { ScanLine, UserSearch, History, LogOut, Tag, Newspaper, Home, Check, Shield, Lightbulb } from "lucide-react";
import { ManagerTutorial, useTutorialAutoOpen } from "@/components/manager/manager-tutorial";
// CP-37.18 — Install-app affordance for managers + front-desk.
import { ManagerPwaInstall } from "@/components/manager/manager-pwa-install";
// CP-37.19 — discovery QR. Same component the agency settings uses,
// surfaced on the front-desk so staff can print/show it to walk-ins.
import { BusinessDiscoveryQR } from "@/components/agency/business-discovery-qr";
import { useRouter, usePathname } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { createClient } from "@/lib/supabase/client";
import { QrScanner } from "@/components/manager/qr-scanner";
import { AwardPointsPanel } from "@/components/manager/award-points-panel";
import { RedemptionFulfillPanel, type RedemptionLookup } from "@/components/manager/redemption-fulfill-panel";
import { ReviewQueue } from "@/components/manager/review-queue";
import { PendingMembershipsQueue } from "@/components/manager/pending-memberships-queue";
import { ManagerOffersPreview } from "@/components/manager/manager-offers-preview";
import { ScannerListener } from "@/components/manager/scanner-listener";
import { CustomerSearch } from "@/components/manager/customer-search";
import { DailyRecapCard } from "@/components/manager/daily-recap-card";
// CP-86: manager-only announcement composer (customer-facing banner + push).
import { AnnouncementComposer } from "@/components/manager/announcement-composer";
// CP-42 (round 3): AtlasValueStrip moved to InsightsDashboard.
import { TeamMembers } from "@/components/team/team-members";
import { FrontDeskPins } from "@/components/team/front-desk-pins";
// CP-43.2: NotificationSettingsPanel removed from the manager dashboard —
// notification types / diagnostics / send-to-all live in the agency
// settings tab only. The desk stays focused on day-to-day ops.
import { OffersManager } from "@/components/agency/offers-manager";
import { AutomatedOffersManager } from "@/components/agency/automated-offers-manager";
import { NewsManager } from "@/components/agency/news-manager";
// Products manager removed — Atlas is loyalty-only.
// Booking removed — Atlas is loyalty-only.
import { ManagerBilling } from "@/components/manager/manager-billing";
import { InsightsDashboard } from "@/components/manager/insights-dashboard";
import { BusinessInsights } from "@/components/agency/business-insights";
import { MembershipBillingSetup } from "@/components/manager/membership-billing-setup";
import { CreditCard, BarChart3, Crown, Users } from "lucide-react";
import { MembersDirectory } from "@/components/manager/members-directory";
import type { Business } from "@/lib/types/database";

// Booking tab removed — Atlas is loyalty-only.
// CP-36b: Notifications tab removed from manager view. Manual broadcast
// + per-business notification toggles now live in the agency admin's
// business settings (NotificationSettings panel) so the entire
// notification surface is owned by the agency, not the front desk.
type ManagerTab = "desk" | "users" | "offers" | "news" | "insights" | "billing" | "membership" | "team";

/** Roles returned by public.current_app_role(business_id) — CP-22 SQL. */
type AppRole = "agency_admin" | "business_manager" | "business_staff" | "customer" | null;

/**
 * CP-130: does the typed value look like a phone number rather than a code?
 * Member codes are 6 hex chars (always contain a letter in practice — and a
 * pure 6-digit one is still shorter than any phone). Redemption codes are 7
 * alphanumerics with letters. So: 7+ digits and NO letters = phone.
 */
function isPhoneLike(raw: string): boolean {
  const s = raw.trim();
  if (/[A-Za-z]/.test(s)) return false;
  const digits = s.replace(/\D/g, "");
  return digits.length >= 7;
}

/** (805) 555-0123 for the error copy; leaves non-10-digit strings as-is. */
function formatPhone(digits: string): string {
  const d = digits.length === 11 && digits.startsWith("1") ? digits.slice(1) : digits;
  if (d.length !== 10) return digits;
  return `(${d.slice(0, 3)}) ${d.slice(3, 6)}-${d.slice(6)}`;
}

// CP-22: front-desk (business_staff) is locked out of Billing + Insights —
// they don't see the tabs, and the underlying RPCs are RLS-gated on
// is_business_manager() too so a direct API call also returns nothing.
function managerTabsFor(_business: Business, role: AppRole): { id: ManagerTab; label: string; icon: React.ReactNode }[] {
  const isManager = role === "business_manager" || role === "agency_admin";
  const tabs: { id: ManagerTab; label: string; icon: React.ReactNode }[] = [
    { id: "desk", label: "Front desk", icon: <Home className="h-4 w-4" /> },
    // CP-48: Users directory — visible to front desk too (support/debug).
    { id: "users", label: "Users", icon: <Users className="h-4 w-4" /> },
  ];
  if (isManager) {
    tabs.push({ id: "insights", label: "Insights", icon: <BarChart3 className="h-4 w-4" /> });
  }
  tabs.push({ id: "offers", label: "Offers", icon: <Tag className="h-4 w-4" /> });
  tabs.push({ id: "news",   label: "News",   icon: <Newspaper className="h-4 w-4" /> });
  if (isManager) {
    tabs.push({ id: "billing",    label: "Billing",    icon: <CreditCard className="h-4 w-4" /> });
    tabs.push({ id: "membership", label: "Membership", icon: <Crown className="h-4 w-4" /> });
    // CP-31: managers can invite front-desk staff for their own business.
    tabs.push({ id: "team",       label: "Team",       icon: <Shield className="h-4 w-4" /> });
    // CP-36b: Notifications tab removed — moved to agency admin's
    // per-business settings (toggles + composer live there now).
  }
  return tabs;
}

type Member = {
  membership_id: string; user_id: string; full_name: string | null;
  email: string | null; phone: string | null;
  points_balance: number; tier: string; joined_at: string; visit_count: number;
};

type LedgerRow = {
  id: string;
  delta: number;
  rule_type: string;
  notes: string | null;
  created_at: string;
  // CP-42: joined from memberships/profiles in the page loader so the
  // front desk sees who each transaction belongs to.
  customer_name?: string | null;
};

export function ManagerDashboard({ business: initialBusiness, recent }: { business: Business; recent: LedgerRow[] }) {
  const router = useRouter();
  const pathname = usePathname();
  const [business, setBusiness] = useState<Business>(initialBusiness);
  const [tab, setTab] = useState<ManagerTab>("desk");
  const [mode, setMode] = useState<"idle" | "scanning" | "code-entry">("idle");
  const [code, setCode] = useState("");
  const [member, setMember] = useState<Member | null>(null);
  // CP-95: remember the last member the desk worked with, so staff can
  // reopen them in one tap without asking the customer to scan again.
  const [lastMember, setLastMember] = useState<Member | null>(null);
  const [redemption, setRedemption] = useState<RedemptionLookup | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [offersSubTab, setOffersSubTab] = useState<"one-time" | "automated">("one-time");
  const [savingBiz, startBizSave] = useTransition();
  const [bizSavedAt, setBizSavedAt] = useState<Date | null>(null);

  // CP-22: figure out which role the caller has so we can hide Billing +
  // Insights from front desk. RLS still enforces the actual data block —
  // this is purely so staff don't see options they can't use.
  const [role, setRole] = useState<AppRole>(null);

  // CP-37.5: tutorial walkthrough state. Auto-opens once per role the
  // first time someone signs in (persisted to localStorage). Header
  // lightbulb button re-opens it any time.
  // CP-68.1: the tutorial's Role type has no "customer" — customers get no tutorial.
  const [autoOpen, dismissAutoOpen] = useTutorialAutoOpen(role === "customer" ? null : role);
  const [tutorialOpen, setTutorialOpen] = useState(false);
  useEffect(() => {
    if (autoOpen) setTutorialOpen(true);
  }, [autoOpen]);
  useEffect(() => {
    const supabase = createClient();
    (async () => {
      const { data } = await supabase.rpc("current_app_role", { p_business_id: business.id });
      setRole((typeof data === "string" ? data : (data as any)?.[0]) as AppRole);
    })();
  }, [business.id]);

  const visibleTabs = managerTabsFor(business, role);
  // If the user clicked into a tab that role-loading then disallows
  // (e.g. they were on Billing and the role resolved to business_staff),
  // bounce them back to the always-available Front desk.
  useEffect(() => {
    if (!visibleTabs.some(t => t.id === tab)) setTab("desk");
  }, [visibleTabs, tab]);

  /** Save patches to the business record (products edits etc.). */
  function persistBusiness(patch: Partial<Business>) {
    const next = { ...business, ...patch };
    setBusiness(next);
    startBizSave(async () => {
      const supabase = createClient();
      const { error } = await supabase
        .from("businesses")
        .update({ services: next.services })
        .eq("id", business.id);
      if (!error) setBizSavedAt(new Date());
      else alert("Save failed: " + error.message);
    });
  }

  // CP-98: scan de-dupe. The camera scanner decodes the same QR many times
  // per second while it's in view, and USB scanners can double-trigger —
  // both used to fire resolveCode repeatedly ("scans twice" / flaky feel).
  // One lookup in flight at a time, and the same code is ignored for 2.5s.
  const resolvingRef = useRef(false);
  const lastScanRef = useRef<{ code: string; at: number }>({ code: "", at: 0 });

  /** Smart resolver — tries member code first, then redemption code. */
  async function resolveCode(rawCode: string) {
    const c = rawCode.trim().toUpperCase();
    if (!c) { setErr("Empty code."); return; }
    const now = Date.now();
    if (resolvingRef.current) return;
    if (lastScanRef.current.code === c && now - lastScanRef.current.at < 2500) return;
    resolvingRef.current = true;
    lastScanRef.current = { code: c, at: now };
    try {
      await resolveCodeInner(c);
    } finally {
      resolvingRef.current = false;
    }
  }

  async function resolveCodeInner(c: string) {
    setErr(null);

    const supabase = createClient();

    // 0. CP-130: a PHONE NUMBER is the front desk's universal backup identity
    //    (Dutch Bros, Square, Toast, Bowlero, Topgolf all do this). Customers
    //    know their number; nobody knows a 6-char code. If what was typed is
    //    7+ digits with no letters, resolve by phone and stop — the code
    //    resolvers below would only ever miss on an all-digit string anyway.
    if (isPhoneLike(c)) {
      const { data: phData, error: phErr } = await supabase.rpc("resolve_member_by_phone",
        { p_phone: c, p_business_id: business.id });
      if (phErr) {
        setErr(`Couldn't look up that number — ${phErr.message}`);
        setMode("idle");
        return;
      }
      if (phData && phData.length > 0) {
        setMember(phData[0] as Member);
        setLastMember(phData[0] as Member);
        setMode("idle");
        return;
      }
      const digits = c.replace(/\D/g, "");
      setErr(digits.length < 10
        ? `No single member ends in ${digits}. Try the full 10-digit number.`
        : `No member with the number ${formatPhone(digits)} at this shop. Check the digits, or search by name below.`);
      return;
    }

    // 1. Try as a member code (6 hex chars)
    // CP-117: surface RPC errors instead of swallowing them. Previously the
    // error field was ignored, so any failure from this function (e.g. a
    // permission-gate helper that errored on a drifted DB) was masked as a
    // plain "not found" for EVERY code — the front desk had no way to tell a
    // real missing code from a broken lookup. Now a genuine error is shown.
    const { data: memData, error: memErr } = await supabase.rpc("resolve_member_by_code",
      { p_code: c, p_business_id: business.id });
    if (memErr) {
      setErr(`Couldn't look up that code — ${memErr.message}`);
      setMode("idle");
      return;
    }
    if (memData && memData.length > 0) {
      setMember(memData[0] as Member);
      setLastMember(memData[0] as Member);
      setMode("idle");
      return;
    }

    // 2. Try as a redemption code (7 alphanumeric)
    const { data: redData, error: redErr } = await supabase.rpc("resolve_redemption_by_code",
      { p_code: c, p_business_id: business.id });
    if (redErr) {
      setErr(`Couldn't look up that code — ${redErr.message}`);
      setMode("idle");
      return;
    }
    if (redData && redData.length > 0) {
      setRedemption(redData[0] as RedemptionLookup);
      setMode("idle");
      return;
    }

    // 3. CP-36b: try as a saved-gift code (7 alphanumeric too). When the
    //    cp36 SQL is applied, customers can present a saved-offer QR and
    //    the front desk fulfills it via fulfill_saved_offer.
    const { data: giftData, error: giftErr } = await supabase.rpc("resolve_saved_offer_by_code",
      { p_code: c, p_business_id: business.id });
    if (giftErr) {
      setErr(`Couldn't look up that code — ${giftErr.message}`);
      setMode("idle");
      return;
    }
    if (giftData && giftData.length > 0) {
      const g = giftData[0] as { saved_id: string; title: string; fulfilled_at: string | null };
      if (g.fulfilled_at) {
        setErr(`Gift "${g.title}" was already redeemed.`);
      } else if (confirm(`Fulfill gift: "${g.title}"?`)) {
        const { error: fulfillErr } = await supabase.rpc("fulfill_saved_offer", { p_saved_id: g.saved_id });
        if (fulfillErr) setErr(`Couldn't fulfill — ${fulfillErr.message}`);
        else { setMode("idle"); router.refresh(); return; }
      }
      setMode("idle");
      return;
    }

    setErr(`No member, redemption, or gift found with code "${c}".`);
  }

  async function signOut() {
    const supabase = createClient();
    await supabase.auth.signOut();
    // CP-45: slug-aware — path-based access lives at /<slug>/manage, so a
    // bare "/login" loses the slug and 404s. Subdomain stays "/login".
    const base = pathname?.match(/^(.*?)\/manage(\/|$)/)?.[1] ?? "";
    router.push(`${base}/login`);
    router.refresh();
  }

  // Routed views
  // CP-98: the ScannerListener stays mounted while a panel is open, so the
  // desk can scan the NEXT customer without closing anything first — the
  // new scan simply swaps the panel. True "scan → pops up", zero clicks.
  if (member) {
    return (
      <>
        <ScannerListener onScan={(code) => resolveCode(code)} />
        <AwardPointsPanel
          business={business}
          member={member}
          onClose={() => { setMember(null); router.refresh(); }}
        />
      </>
    );
  }
  if (redemption) {
    return (
      <>
        <ScannerListener onScan={(code) => resolveCode(code)} />
        <RedemptionFulfillPanel
          business={business}
          redemption={redemption}
          onClose={() => { setRedemption(null); router.refresh(); }}
        />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-zinc-50">
      {/* CP-30: USB QR scanner support — catches HID-class scanner
          keystrokes and runs resolveCode. No UI footprint.
          CP-98: enabled on EVERY tab (was desk-only) — staff can be on
          Offers or Users when a customer walks up, and the scan still
          pops the award panel instantly. */}
      <ScannerListener
        onScan={(code) => resolveCode(code)}
      />
      <header className="bg-white border-b">
        <div className="max-w-2xl lg:max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {business.logo_url ? (
              /* eslint-disable-next-line @next/next/no-img-element */
              <img src={business.logo_url} alt="" className="h-8" />
            ) : (
              <div className="h-8 px-3 rounded-full flex items-center text-white text-xs font-bold"
                style={{ background: business.brand_colors.primary }}>{business.name[0]}</div>
            )}
            <div>
              <div className="text-sm font-bold">{business.name}</div>
              {/* CP-42 fix: was hardcoded to "Front desk" for every role —
                  misleading for agency_admin / manager viewers. Surface
                  the actual role so it matches what the user can do. */}
              <div className="text-[10px] text-muted-foreground tracking-wider uppercase">
                {role === "agency_admin"
                  ? "Agency admin"
                  : role === "business_manager"
                  ? "Manager"
                  : role === "business_staff"
                  ? "Front desk"
                  : "Manage"}
              </div>
            </div>
          </div>
          {/* CP-37.5: header tutorial button. Subtle until tapped —
              walks the user through their role's features one step
              at a time. Auto-opens on first sign-in for new accounts.
              CP-37.18: install-app affordance now sits next to it. */}
          <div className="flex items-center gap-1">
            <ManagerPwaInstall primary={business.brand_colors.primary} businessName={business.name} />
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setTutorialOpen(true)}
              title="Show tutorial"
              aria-label="Show tutorial"
            >
              <Lightbulb className="h-4 w-4 mr-1" />
              <span className="hidden sm:inline">Tutorial</span>
            </Button>
            <Button variant="ghost" size="sm" onClick={signOut}><LogOut className="h-4 w-4 mr-1"/>Sign out</Button>
          </div>
        </div>
      </header>

      {/* CP-37.5: tutorial walkthrough overlay. */}
      <ManagerTutorial
        role={role === "customer" ? null : role}
        primary={business.brand_colors.primary}
        open={tutorialOpen}
        onClose={() => {
          setTutorialOpen(false);
          dismissAutoOpen();
        }}
      />

      {/* Tabs */}
      <div className="bg-white border-b">
        <div className="max-w-2xl lg:max-w-7xl mx-auto px-2 flex overflow-x-auto">
          {visibleTabs.map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={cn(
                "flex items-center gap-1.5 px-3 py-3 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap",
                tab === t.id
                  ? "border-zinc-900 text-zinc-900"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              )}
            >
              {t.icon}{t.label}
            </button>
          ))}
          {bizSavedAt && (
            <span className="ml-auto self-center text-[11px] text-emerald-600 flex items-center gap-1 pr-2">
              <Check className="h-3 w-3"/> Saved
            </span>
          )}
        </div>
      </div>

      <main className="max-w-2xl lg:max-w-7xl mx-auto p-4 space-y-4">
        {tab === "desk" && (
          <>
            {/* CP-42 (round 3): Scanner hero MOVES UP to the top — Andrew
                uses this every shift, so it gets the first visual slot.
                Value strip moved to Insights where the impact data
                belongs; daily recap drops below scanner. */}

            {/* Hero CTA — CP-42: bigger title, glowing CTA, decorative
                blobs, brighter accent for the action buttons. */}
            <div
              className="rounded-3xl p-6 text-white relative overflow-hidden shadow-xl"
              style={{ background: `linear-gradient(135deg, ${business.brand_colors.primary} 0%, ${business.brand_colors.secondary} 100%)` }}
            >
              <div className="absolute -top-12 -right-12 w-48 h-48 rounded-full bg-white/15 blur-3xl pointer-events-none" />
              <div className="absolute -bottom-16 -left-12 w-56 h-56 rounded-full bg-black/15 blur-3xl pointer-events-none" />
              <div className="relative">
                <div className="inline-flex items-center gap-1.5 text-[10px] font-black tracking-widest uppercase bg-white/20 backdrop-blur-sm px-2.5 py-1 rounded-full mb-2">
                  <ScanLine className="h-3 w-3" /> Front desk · live
                </div>
                <h1 className="text-2xl font-black drop-shadow-sm">Scan to start</h1>
                <p className="text-sm text-white/90 mt-1.5 leading-snug">
                  Scan a member's QR to award points, or scan a reward code to deliver a redemption.
                </p>
                <div className="mt-5 grid grid-cols-2 gap-2.5">
                  <Button
                    onClick={() => setMode("scanning")}
                    className="bg-white text-zinc-900 hover:bg-zinc-100 h-12 font-extrabold text-base shadow-lg"
                  >
                    <ScanLine className="h-5 w-5 mr-2"/> Scan code
                  </Button>
                  <Button
                    onClick={() => setMode("code-entry")}
                    className="bg-white/15 backdrop-blur-sm border border-white/40 text-white hover:bg-white/25 h-12 font-extrabold text-base"
                  >
                    <UserSearch className="h-5 w-5 mr-2"/> Phone number
                  </Button>
                </div>
                {/* CP-130: phone number is the backup — say so where staff look. */}
                <div className="mt-3.5 grid grid-cols-3 gap-3 text-[11px] text-white/90 font-medium">
                  <div className="flex items-center gap-1.5"><ScanLine className="h-3.5 w-3.5"/> Scan their QR</div>
                  <div className="flex items-center gap-1.5"><UserSearch className="h-3.5 w-3.5"/> Or type their phone number</div>
                  {/* CP-30: USB scanner status indicator */}
                  <div className="flex items-center gap-1.5">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-300 animate-pulse" />
                    USB scanner ready
                  </div>
                </div>
              </div>
            </div>

            {/* CP-95: one-tap reopen of the last customer served — the panel
                re-fetches their live balance on open, so this is always
                safe even after awards. Kills the "please scan again so I
                can enter what you spent" dance. */}
            {lastMember && (
              <button
                type="button"
                onClick={() => setMember(lastMember)}
                className="w-full rounded-2xl border bg-white p-3.5 flex items-center gap-3 text-left shadow-sm ring-1 ring-black/5 active:scale-[0.99] hover:shadow-md transition"
              >
                <div
                  className="h-10 w-10 rounded-full flex items-center justify-center text-white font-bold shrink-0"
                  style={{ background: business.brand_colors.primary }}
                >
                  {(lastMember.full_name ?? "?")[0].toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-[10px] uppercase tracking-widest font-bold text-zinc-400">
                    Previous customer
                  </div>
                  <div className="text-sm font-bold truncate">
                    {lastMember.full_name ?? "Unnamed member"}
                  </div>
                </div>
                <span
                  className="shrink-0 inline-flex items-center gap-1.5 text-[11px] font-extrabold px-3 py-1.5 rounded-full text-white"
                  style={{ background: business.brand_colors.primary }}
                >
                  <History className="h-3.5 w-3.5" /> Reopen
                </span>
              </button>
            )}

            {/* CP-43.4: prominent "install on this computer" card. Self-hides
                once the app is installed / running standalone, so it only
                shows during first-time setup at the front desk. */}
            <ManagerPwaInstall
              primary={business.brand_colors.primary}
              businessName={business.name}
              variant="card"
            />

            {/* Scanner panel */}
            {mode === "scanning" && (
              <div className="rounded-2xl border bg-white p-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-sm">Point your camera at the QR</h3>
                  <Button variant="ghost" size="sm" onClick={() => setMode("idle")}>Cancel</Button>
                </div>
                <QrScanner onScan={(value) => resolveCode(value)} />
                {err && <p className="text-sm text-red-600 mt-2">{err}</p>}
              </div>
            )}

            {/* Manual code entry — CP-30: larger touch targets and clearer
                empty/error states for live front-desk use. */}
            {mode === "code-entry" && (
              <div className="rounded-2xl border bg-white p-5">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold text-base">Phone number or code</h3>
                  <Button variant="ghost" size="sm" onClick={() => setMode("idle")}>Cancel</Button>
                </div>
                <form onSubmit={(e) => { e.preventDefault(); resolveCode(code); }} className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-xs text-muted-foreground uppercase tracking-widest font-bold">
                      Ask for their phone number
                    </Label>
                    {/* CP-130: phone number is the backup identity. The box
                        takes a 10-digit number (any formatting) OR the old
                        member / redemption codes — isPhoneLike() routes it.
                        inputMode="tel" brings up the number pad on tablets;
                        letters still type for codes. */}
                    <Input
                      value={code}
                      onChange={e => setCode(e.target.value.toUpperCase())}
                      placeholder="(805) 555-0123"
                      maxLength={16}
                      autoFocus
                      inputMode="tel"
                      autoComplete="off"
                      // CP-30: noticeably larger input — easier to type into on
                      // a tablet at the front desk without misfiring.
                      className={cn(
                        "font-mono text-2xl text-center uppercase h-14",
                        isPhoneLike(code) ? "tracking-[0.15em]" : "tracking-[0.4em]",
                      )}
                    />
                    <p className="text-[11px] text-zinc-500 text-center">
                      Their 10-digit phone number, or a member / redemption code.
                    </p>
                  </div>
                  {err && (
                    <div className="rounded-lg bg-rose-50 border border-rose-200 p-3 text-sm text-rose-700">
                      {err}
                    </div>
                  )}
                  <Button type="submit" className="w-full h-12 text-base font-bold">
                    Look up
                  </Button>
                </form>
              </div>
            )}

            {/* CP-42 (round 3): customer search + recap moved BELOW the
                scanner so the scan-to-start CTA gets the top slot. */}
            <CustomerSearch
              businessId={business.id}
              primary={business.brand_colors.primary}
              onPick={(h) => {
                const m: Member = {
                  membership_id: h.membership_id,
                  user_id: h.user_id,
                  full_name: h.full_name,
                  email: h.email,
                  phone: h.phone,
                  points_balance: h.points_balance,
                  tier: h.tier,
                  joined_at: h.joined_at,
                  visit_count: h.visit_count,
                };
                setMember(m);
                setLastMember(m);
              }}
            />

            <DailyRecapCard
              businessId={business.id}
              businessName={business.name}
              primary={business.brand_colors.primary}
              secondary={business.brand_colors.secondary}
            />

            {/* CP-86: announcements — MANAGER-ONLY (business_staff never
                sees it; the SQL RPCs are manager-gated too). */}
            {(role === "business_manager" || role === "agency_admin") && (
              <AnnouncementComposer
                businessId={business.id}
                primary={business.brand_colors.primary}
              />
            )}

            {/* CP-48: insights moved OFF the front-desk tab — they live in the
                Insights tab. The desk stays focused on day-to-day ops. */}

            <ReviewQueue business={business} />

            {/* CP-34: pending memberships awaiting in-person / external-link
                payment confirmation. Self-hides when empty. */}
            <PendingMembershipsQueue business={business} />

            {/* CP-43.2: notification types / diagnostics / send-to-all
                removed from the front desk per Andrew — those live in the
                agency settings tab. Keeps the desk focused on day-to-day ops. */}

            {/* Recent activity */}
            <div className="rounded-2xl border bg-white">
              <div className="px-4 py-3 border-b flex items-center gap-2">
                <History className="h-4 w-4 text-muted-foreground" />
                <h3 className="font-semibold text-sm">Recent activity</h3>
              </div>
              <div className="divide-y">
                {recent.length === 0 ? (
                  <div className="p-6 text-center text-sm text-muted-foreground">No transactions yet.</div>
                ) : recent.map(r => {
                  // CP-42: avatar circle from initials makes the customer
                  // identity scannable at a glance.
                  const name = r.customer_name ?? "Guest";
                  const initials = name
                    .split(" ")
                    .map(s => s[0])
                    .filter(Boolean)
                    .slice(0, 2)
                    .join("")
                    .toUpperCase() || "?";
                  return (
                    <div key={r.id} className="px-4 py-3 flex items-center gap-3 text-sm">
                      <div
                        className="h-9 w-9 rounded-full flex items-center justify-center text-white font-bold text-xs shrink-0"
                        style={{ background: `linear-gradient(135deg, ${business.brand_colors.primary}, ${business.brand_colors.primary}cc)` }}
                      >
                        {initials}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold truncate">{name}</div>
                        <div className="text-[11px] text-muted-foreground flex items-center gap-1.5">
                          <span className="capitalize">{r.rule_type.replace(/_/g, " ")}</span>
                          <span className="opacity-50">•</span>
                          <span>{new Date(r.created_at).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}</span>
                        </div>
                      </div>
                      <div className={r.delta >= 0 ? "text-emerald-600 font-bold shrink-0" : "text-rose-600 font-bold shrink-0"}>
                        {r.delta >= 0 ? "+" : ""}{r.delta} pts
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* CP-43.2: app QR moved here — directly UNDER the activity log,
                per Andrew. Front desk shows it to walk-ins to open/join the
                app. */}
            <BusinessDiscoveryQR business={business} />
          </>
        )}

        {tab === "users" && (
          <MembersDirectory
            businessId={business.id}
            primary={business.brand_colors.primary}
            onPick={(m) => setMember(m as Member)}
          />
        )}

        {tab === "insights" && (
          <div className="space-y-4">
            <InsightsDashboard business={business} />
            {/* CP-48: customer revenue / transactions graphs live here too. */}
            <BusinessInsights business={business} />
          </div>
        )}

        {tab === "offers" && (
          <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-6">
            <div className="space-y-4 min-w-0">
              {/* Sub-tabs: One-Time / Automated */}
              <div className="flex rounded-xl bg-zinc-100 p-1 gap-1">
                <button
                  onClick={() => setOffersSubTab("one-time")}
                  className={cn(
                    "flex-1 rounded-lg py-2 text-xs font-semibold transition-colors",
                    offersSubTab === "one-time"
                      ? "bg-white text-zinc-900 shadow-sm"
                      : "text-muted-foreground hover:text-foreground",
                  )}
                >
                  One-Time offers
                </button>
                <button
                  onClick={() => setOffersSubTab("automated")}
                  className={cn(
                    "flex-1 rounded-lg py-2 text-xs font-semibold transition-colors",
                    offersSubTab === "automated"
                      ? "bg-white text-zinc-900 shadow-sm"
                      : "text-muted-foreground hover:text-foreground",
                  )}
                >
                  ✨ Automated
                </button>
              </div>

              {offersSubTab === "one-time"  && <OffersManager           business={business} />}
              {offersSubTab === "automated" && <AutomatedOffersManager  business={business} />}
            </div>

            {/* CP-35: live phone-frame preview, scoped to offers only.
                Hidden on small screens (front-desk tablets); visible on
                lg+ so the manager can see customer banner + featured
                offer change in real time as they edit. */}
            <ManagerOffersPreview business={business} />
          </div>
        )}

        {tab === "news"       && <NewsManager             business={business} />}
        {tab === "billing"    && <ManagerBilling         business={business} />}
        {tab === "membership" && <MembershipBillingSetup business={business} />}
        {tab === "team"       && (role === "business_manager" || role === "agency_admin") && (
          <div className="space-y-6">
            <TeamMembers
              businessId={business.id}
              callerRole={role}
              primary={business.brand_colors.primary}
            />
            {/* CP-49: PIN-based front desk management. */}
            <FrontDeskPins
              businessId={business.id}
              slug={business.slug}
              primary={business.brand_colors.primary}
            />
          </div>
        )}
        {/* CP-36b: notifications surface (composer + toggles) moved to the
            agency admin's per-business settings. The manager dashboard no
            longer carries this tab — keeps the front-desk surface focused
            on day-to-day ops. */}
      </main>
    </div>
  );
}
