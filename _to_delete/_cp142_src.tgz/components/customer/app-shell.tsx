"use client";
import { Home, ShoppingBag, ScanLine, Gift, CalendarClock, Flame, Tag, Crown, UserRound } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import type { WidgetConfig } from "@/lib/types/database";
import { presetSpec, type TabId } from "@/lib/layout-presets";
import { useReviewStatus, reviewBadgeTone } from "@/lib/hooks/use-review-status";
import { readableTextColor } from "@/lib/patterns";
import { createClient } from "@/lib/supabase/client";
// CP-42: one-time first-visit nudge pointing at the bell.
import { EnablePushNudge } from "./enable-push-nudge";

type TabDef = { href: string; label: string; icon: React.ComponentType<{ className?: string; style?: React.CSSProperties }> };

const HOME:    TabDef = { href: "",         label: "Home",    icon: Home };
const SHOP:    TabDef = { href: "/shop",    label: "Shop",    icon: ShoppingBag };
const BOOK:    TabDef = { href: "/book",    label: "Book",    icon: CalendarClock };
// CP-39: renamed "Scan" → "Check in" so the bottom nav matches the
// language we use everywhere else (front-desk scans a QR, customer
// "checks in"). Same /scan route under the hood.
const SCAN:    TabDef = { href: "/scan",    label: "Check in", icon: ScanLine };
const REWARDS: TabDef = { href: "/rewards", label: "Rewards", icon: Gift };
// CP-99 Phase 4/5: the streak Reward Road is a first-class destination.
// (Check in = "record my visit" action; Streaks = progress/motivation —
// deliberately separate tabs.)
const STREAKS: TabDef = { href: "/streaks", label: "Streaks", icon: Flame };
// CP-99: Profile moved to the header hamburger menu (header-actions.tsx) —
// the /profile route is unchanged, it just left the bar.
// CP-131: tabs the niche presets can put on the bar.
const OFFERS:     TabDef = { href: "/offers",     label: "Offers",     icon: Tag };
const MEMBERSHIP: TabDef = { href: "/membership", label: "Membership", icon: Crown };
const PROFILE:    TabDef = { href: "/profile",    label: "Profile",    icon: UserRound };

const TAB_BY_ID: Record<TabId, TabDef> = {
  home: HOME, scan: SCAN, rewards: REWARDS, streaks: STREAKS,
  offers: OFFERS, book: BOOK, membership: MEMBERSHIP, profile: PROFILE,
};
void SHOP; // Shop tab retired in CP-06; kept so the icon import stays honest.

/**
 * Build the tab list for a business.
 *
 * CP-131: the set and order come from the business's layout preset
 * (lib/layout-presets.ts). "custom" (and every pre-CP-131 app) yields the
 * classic Home · Check in · Rewards · Streaks bar. Presets may relabel a
 * tab (smoke shops say "Deals", entertainment says "Pass") — the label
 * comes from the preset, the route from the tab id. Capped at 5.
 */
export function tabsForConfig(_w: WidgetConfig, layoutPreset?: string | null): TabDef[] {
  const spec = presetSpec(layoutPreset);
  return spec.tabs.slice(0, 5).map(t => ({ ...TAB_BY_ID[t.id], label: t.label }));
}

/**
 * CP-121 (upgrades CP-120): the Streaks tab wears state-aware badges.
 *
 *   gift     — an EARNED, unclaimed streak gift is waiting (server truth,
 *              via list_streak_gifts): gold gift badge. Clears when claimed.
 *   urgent   — the streak is about to die: streak > 0, not yet checked in
 *              this period, and under 25% of the period (max 24h) remains.
 *   progress — the streak moved since they last opened the Streaks tab
 *              (device-local last-seen, CP-120 behavior).
 *
 * Badge priority at render: gift (gold, + red ring when also urgent) >
 * red "!" (urgent or unseen progress).
 */
type StreakNudge = { gift: boolean; urgent: boolean; progress: boolean };

function useStreakNudge(
  businessId: string | null,
  membershipId: string | null,
  onStreaksTab: boolean,
): StreakNudge {
  const [n, setN] = useState<StreakNudge>({ gift: false, urgent: false, progress: false });

  useEffect(() => {
    if (!businessId || !membershipId) { setN({ gift: false, urgent: false, progress: false }); return; }
    let cancelled = false;
    const key = `atlas-streak-seen:${businessId}`;
    (async () => {
      try {
        const supabase = createClient();
        const [{ data: sData }, { data: gData }] = await Promise.all([
          supabase.rpc("get_streak_status", { p_business_id: businessId, p_membership_id: membershipId }),
          supabase.rpc("list_streak_gifts", { p_business_id: businessId, p_membership_id: membershipId }),
        ]);
        if (cancelled) return;
        const row = (Array.isArray(sData) ? sData[0] : sData) as {
          is_enabled?: boolean; current_streak?: number; checked_in_this_period?: boolean;
          period_start?: string | null; period_end?: string | null;
        } | null;
        if (!row?.is_enabled) { setN({ gift: false, urgent: false, progress: false }); return; }
        const cur = Number(row.current_streak ?? 0);

        // Unclaimed, unexpired gift? (list_streak_gifts errors silently on a
        // pre-cp121 DB — the catch below keeps the nav alive.)
        const gift = ((gData ?? []) as Array<{ claimed_at: string | null; expires_at: string }>)
          .some(g => !g.claimed_at && new Date(g.expires_at).getTime() > Date.now());

        // Streak about to die (engine period math, same fields the desk uses).
        let urgent = false;
        const end = row.period_end ? new Date(row.period_end).getTime() : NaN;
        const start = row.period_start ? new Date(row.period_start).getTime() : NaN;
        if (cur > 0 && !row.checked_in_this_period && Number.isFinite(end) && Number.isFinite(start)) {
          const len = end - start;
          const remaining = end - Date.now();
          urgent = remaining > 0 && remaining < Math.min(len * 0.25, 24 * 3600_000);
        }

        let seen = -1;
        try { seen = Number(localStorage.getItem(key) ?? "-1"); } catch { /* private mode */ }
        let progress = cur > 0 && cur > seen;
        if (onStreaksTab) {
          try { localStorage.setItem(key, String(cur)); } catch { /* ignore */ }
          progress = false;
        }
        setN({ gift, urgent, progress });
      } catch { /* silent — a nudge must never break the nav */ }
    })();
    return () => { cancelled = true; };
  }, [businessId, membershipId, onStreaksTab]);

  return n;
}

export function CustomerAppShell({
  primary,
  widgetConfig,
  children,
  /** CP-32: passed by the customer layout so we can live-update the
   *  Rewards-tab red/orange "!" badge for unsubmitted/pending Google
   *  review verification. */
  businessId,
  membershipId,
  backgroundStyle,
  header,
  surfaceFg,
  chromeColor,
  reviewUrl,
  layoutPreset,
}: {
  primary: string;
  widgetConfig: WidgetConfig;
  /** CP-131: businesses.layout_preset — picks the tab set (lib/layout-presets.ts). */
  layoutPreset?: string | null;
  children: React.ReactNode;
  businessId?: string | null;
  membershipId?: string | null;
  /** CP-52.2: faint background pattern. Applied HERE (not the layout) because
   *  this shell's wrapper would otherwise paint over it with bg-zinc-50. */
  backgroundStyle?: React.CSSProperties;
  /** CP-52.4: shared top header (logo + quick actions) on every tab. */
  header?: React.ReactNode;
  /** CP-54: auto-contrast text color for content sitting directly on the
   *  surface (section headings). Cards keep their own explicit colors. */
  surfaceFg?: string;
  /** CP-54: header / bottom-nav background color (null = default white). */
  chromeColor?: string | null;
  /** CP-103 (QA S-03): the Rewards "!" review nudge only makes sense once
   *  the business has a Google review link to send people to. */
  reviewUrl?: string | null;
}) {
  const pathname = usePathname();
  // CP-45 404 fix: the nav used a hard-coded `/app` base. That works on the
  // installed PWA (subdomain → middleware injects the slug), but breaks
  // path-based access — the agency preview and the "Customer app" button
  // open /<slug>/app, where a hard `/app/rewards` link has no slug → 404.
  // Derive the base from the CURRENT pathname instead, so links work on
  // both the subdomain (`/app/...`) and path (`/<slug>/app/...`) forms.
  // The regex anchors `/app` at a segment boundary so slugs like
  // "apple-spa" can't false-match.
  const basePath = pathname?.match(/^(.*?\/app)(\/|$)/)?.[1] ?? "/app";
  const tabs = tabsForConfig(widgetConfig, layoutPreset);

  // CP-55: adapt the bottom-nav icon/label colors to the nav (chrome) color.
  // On a dark nav, grey buttons blend — use light text; active = white so it
  // stays visible even when the brand primary is itself dark.
  const navIsDark = !!chromeColor && readableTextColor(chromeColor) === "#f4f4f5";
  const navActive = navIsDark ? "#ffffff" : primary;
  const navInactive = navIsDark ? "rgba(255,255,255,0.62)" : "#9ca3af";
  // CP-69: subtle pill behind the active tab's icon so "where am I" is
  // obvious at a glance (brand-tinted on light chrome, white-tinted on dark).
  const navPill = navIsDark ? "rgba(255,255,255,0.16)" : `${primary}16`;

  // CP-32: review nudge badge on Rewards tab.
  // Visible review widget? then we care. If the business hasn't enabled
  // reviews this hook still returns "none" (no review yet) — but we only
  // surface the badge when widget_config.reviews is on AND the business
  // has a google_review_url-style URL set. We can't read that here without
  // a fetch, so we just gate on widget_config.reviews.
  // CP-103: gated on the review LINK too — no link, no nudge.
  const reviewsLive = !!widgetConfig?.reviews && !!reviewUrl;
  const reviewStatus = useReviewStatus(
    reviewsLive ? (businessId ?? null) : null,
    reviewsLive ? (membershipId ?? null) : null,
  );
  const reviewTone = reviewsLive ? reviewBadgeTone(reviewStatus) : false;

  // CP-120: streak "!" — lights up when the streak moved since the member
  // last opened the Streaks tab; clears itself the moment they look.
  const onStreaksTab = pathname === `${basePath}/streaks`;
  const streak = useStreakNudge(businessId ?? null, membershipId ?? null, onStreaksTab);

  return (
    <div
      className="min-h-screen flex flex-col"
      // CP-54: expose the auto-contrast color as a CSS var. On-background
      // section headings opt in via color:var(--surf-fg); white content cards
      // keep their own explicit colors, so nothing inside them can blend.
      style={{ ...(backgroundStyle ?? { backgroundColor: "#fafafa" }), ["--surf-fg" as any]: surfaceFg ?? "#18181b" }}
    >
      {/* CP-42: arrow-points-at-bell nudge on first visit when push
          permission is still "default". Self-dismisses after 8s or on
          tap. Stores a flag in localStorage so it never re-shows. */}
      <EnablePushNudge primary={primary} businessId={businessId ?? null} />
      {/* CP-52.4: shared header across every tab. */}
      {header}
      {/* CP-103: clearance grew with the taller nav (pb-20 → pb-24). Any
          surface that cancels this padding must cancel 6rem, not 5rem. */}
      {/* landscape:pb-28 = extra clearance for anyone still on a build that
          can rotate (pre-portrait-lock native, or a mobile browser). */}
      <main className="flex-1 pb-24 landscape:pb-28">{children}</main>
      <nav
        className="fixed bottom-0 left-0 right-0 max-w-md mx-auto border-t px-1 pt-2.5 flex items-center justify-around z-40"
        // CP-110 (mobile): the layout runs viewport-fit=cover, so on notched
        // iPhones the tab bar sat in the home-indicator band and its hit
        // targets fought the system swipe gesture. Pad the bottom by the
        // safe-area inset (falls back to the original 0.625rem on devices
        // without a home indicator). Content clearance above (pb-24) already
        // accounts for the taller bar.
        style={{
          paddingBottom: "calc(0.625rem + env(safe-area-inset-bottom, 0px))",
          ...(chromeColor
            ? { background: chromeColor, borderColor: "rgba(127,127,127,0.28)" }
            : { background: "#ffffff", borderColor: "#e4e4e7" }),
        }}
      >
        {tabs.map(t => {
          // CP-32: red/orange "!" badge on the Rewards tab — itches the
          // user into submitting (or finishing) a Google review.
          // CP-35: when the badge is active, the link includes ?focus=review
          // so the rewards page scrolls directly to the review row.
          const isRewards = t.href === "/rewards"; // CP-131: presets may relabel; key on the route
          const showBadge = isRewards && reviewTone !== false;
          // CP-121: state-aware Streaks badges — gold gift beats red "!";
          // a gift that's ALSO urgent wears a red ring. Hidden while the
          // tab itself is open (they're already looking).
          const isStreaks = t.href === "/streaks";
          const streakActive = pathname === `${basePath}/streaks`;
          const showGiftBadge = isStreaks && !streakActive && streak.gift;
          const showStreakBadge = isStreaks && !streakActive && !streak.gift && (streak.urgent || streak.progress);
          const href = `${basePath}${t.href}` + (showBadge ? "?focus=review" : "");
          const active = pathname === `${basePath}${t.href}` || (t.href === "" && pathname === basePath);
          const Icon = t.icon;
          return (
            <Link key={t.label} href={href} className="flex flex-col items-center gap-1 py-0.5 px-2 flex-1 active:scale-95 transition-transform relative">
              {/* CP-69: active-tab pill — subtle tinted capsule behind the icon. */}
              <div
                className="relative rounded-full px-4 py-1.5 transition-colors"
                style={active ? { background: navPill } : undefined}
              >
                <Icon className={cn("h-6 w-6")} style={{ color: active ? navActive : navInactive }} />
                {showBadge && (
                  <span
                    aria-label={reviewTone === "orange" ? "Review pending verification" : "Google review available"}
                    className={cn(
                      "absolute -top-1.5 -right-2 h-4 w-4 rounded-full text-white text-[10px] font-extrabold flex items-center justify-center shadow ring-2 ring-white",
                      reviewTone === "orange" ? "bg-amber-500" : "bg-rose-500",
                    )}
                    // CP-42: itchy wobble — short rotate-shake bursts every
                    // few seconds so it visually itches the customer into
                    // tapping. Replaces the steady pulse.
                    style={{
                      animation: "atlas-itch-wobble 3.6s ease-in-out infinite",
                      transformOrigin: "center center",
                    }}
                  >!</span>
                )}
                {showGiftBadge && (
                  <span
                    aria-label={streak.urgent
                      ? "Gift waiting — and your streak is about to expire!"
                      : "You have a streak gift ready to claim"}
                    className={cn(
                      "absolute -top-2 -right-2.5 h-[18px] w-[18px] rounded-full flex items-center justify-center shadow",
                      streak.urgent ? "ring-2 ring-rose-500" : "ring-2 ring-white",
                    )}
                    style={{
                      background: "linear-gradient(135deg, #fbbf24, #d97706)",
                      animation: `atlas-itch-wobble ${streak.urgent ? "1.8s" : "3.6s"} ease-in-out infinite`,
                      transformOrigin: "center center",
                    }}
                  >
                    <Gift className="h-2.5 w-2.5 text-white" />
                  </span>
                )}
                {showStreakBadge && (
                  <span
                    aria-label={streak.urgent
                      ? "Your streak is about to expire — check in!"
                      : "Your streak went up — open Streaks to see it"}
                    className="absolute -top-1.5 -right-2 h-4 w-4 rounded-full bg-rose-500 text-white text-[10px] font-extrabold flex items-center justify-center shadow ring-2 ring-white"
                    style={{
                      animation: `atlas-itch-wobble ${streak.urgent ? "1.8s" : "3.6s"} ease-in-out infinite`,
                      transformOrigin: "center center",
                    }}
                  >!</span>
                )}
              </div>
              <span className={cn("text-[11px] leading-none", active ? "font-extrabold" : "font-semibold")} style={{ color: active ? navActive : navInactive }}>{t.label}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
