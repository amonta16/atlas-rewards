import { NextResponse, type NextRequest } from "next/server";
import { updateSession } from "@/lib/supabase/middleware";

/**
 * Multi-tenant routing for Atlas Rewards.
 *
 *   demo.lvh.me:3000          → rewrites to /demo (customer-facing branded view)
 *   demo.atlasrewards.app     → rewrites to /demo
 *   atlasrewards.app          → root landing / agency
 *   agency.atlasrewards.app   → reserved for agency dashboard
 *   lvh.me:3000               → root landing / agency
 *
 * The PWA reads the resolved business slug from the URL pathname after this rewrite.
 */
export async function middleware(request: NextRequest) {
  const url = request.nextUrl.clone();
  const host = request.headers.get("host") ?? "";
  const rootDomain = process.env.NEXT_PUBLIC_ROOT_DOMAIN ?? "lvh.me";

  // Refresh Supabase auth cookies on every request
  const response = await updateSession(request);

  // Strip port (e.g., "demo.lvh.me:3000" → "demo.lvh.me")
  const hostNoPort = host.split(":")[0];

  // Determine the subdomain by removing the root domain
  let subdomain: string | null = null;
  if (hostNoPort === rootDomain || hostNoPort === `www.${rootDomain}`) {
    subdomain = null; // root domain — agency / landing
  } else if (hostNoPort.endsWith(`.${rootDomain}`)) {
    subdomain = hostNoPort.replace(`.${rootDomain}`, "");
  }

  // Reserved subdomains route to agency view. CP-36: added "app",
  // "mail", "blog", "marketing" as defensive entries — common subdomain
  // names a business owner might accidentally pick that should never
  // be treated as a sub-account slug.
  const RESERVED = new Set([
    "www", "agency", "admin", "api",
    "app", "mail", "blog", "marketing", "support", "help",
    "docs", "status", "dev", "staging", "test",
  ]);

  // CP-42 fix: NEVER rewrite root-level static assets (service workers,
  // manifests, robots.txt, sitemap, manifest.json) OR /api/* onto the
  // [business] path — these MUST be served from the project root.
  // Without these bail-outs:
  //   - /sw-push.js was rewritten → 404 → push subscription never registered
  //   - /api/notifications/vapid-public-key was rewritten → 404 → browser
  //     couldn't get the VAPID key to subscribe with
  const ROOT_ASSETS = new Set([
    "/sw.js", "/sw-push.js", "/manifest.json", "/manifest.webmanifest",
    "/robots.txt", "/sitemap.xml", "/atlas-favicon.png", "/atlas-apple-touch.png",
  ]);
  // CP-96.1: legal + support pages are host-agnostic — ONE policy and one
  // support page cover every business, and the Profile tab links to them
  // from business subdomains (where the rewrite below used to turn
  // /legal/terms into /<slug>/legal/terms → 404 inside the phone app).
  const isRootPage = url.pathname === "/support" || url.pathname.startsWith("/legal");
  const isRootAsset = ROOT_ASSETS.has(url.pathname) || url.pathname.startsWith("/api/") || isRootPage;

  if (!isRootAsset && subdomain && !RESERVED.has(subdomain)) {
    // /agency is reserved for the agency dashboard (only reachable from the root domain).
    if (url.pathname.startsWith("/agency")) {
      return response;
    }
    // Avoid double-rewriting if URL already starts with the business slug
    if (url.pathname.startsWith(`/${subdomain}`)) {
      return response;
    }
    // Rewrite the path so app/[business]/... handles it.
    // /login, /signup, /app, /manage all get scoped under the business slug.
    url.pathname = `/${subdomain}${url.pathname === "/" ? "" : url.pathname}`;
    return NextResponse.rewrite(url, { headers: response.headers });
  }

  return response;
}

export const config = {
  matcher: [
    // Skip static, image, and API routes. CP-42: also exclude .js
    // (so service workers like /sw-push.js never get rewritten),
    // .txt, .xml, .webmanifest, .json (manifest.json fallback).
    "/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp|js|txt|xml|webmanifest|json)$).*)",
  ],
};
