import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { AdminAppClient } from "@/components/agency/admin-app-client";
import type { RepLeaderRow, TeamMrrSummary } from "@/lib/types/database";

export const dynamic = "force-dynamic";

/**
 * /agency/admin-app — configure hub for the mobile Field App (CP-63).
 * Admin-only (VAs are bounced).
 */
export default async function AdminAppPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: adminRows } = await supabase
    .from("business_users").select("role")
    .eq("user_id", user.id).eq("role", "agency_admin").limit(1);
  if (!adminRows || adminRows.length === 0) redirect("/agency");

  const [{ data: config }, { data: leaderboard }, { data: team }] = await Promise.all([
    supabase.from("admin_app_config")
      .select("owner_user_id, default_commission_pct, nudges_enabled, nudge_hour, nudge_mon, nudge_tue, nudge_wed, nudge_thu, nudge_fri, nudge_sat, nudge_sun")
      .eq("id", 1).maybeSingle(),
    supabase.rpc("rep_leaderboard"),
    supabase.rpc("team_mrr_summary"),
  ]);
  const teamSummary = (Array.isArray(team) ? team[0] : team) as TeamMrrSummary | null;

  const c: any = config ?? {};
  const nudges = {
    enabled: c.nudges_enabled ?? true,
    hour: Number(c.nudge_hour ?? 8),
    messages: {
      mon: c.nudge_mon ?? "", tue: c.nudge_tue ?? "", wed: c.nudge_wed ?? "",
      thu: c.nudge_thu ?? "", fri: c.nudge_fri ?? "", sat: c.nudge_sat ?? "", sun: c.nudge_sun ?? "",
    },
  };

  const ownerId = (config?.owner_user_id as string | null) ?? null;
  let ownerEmail: string | null = null;
  if (ownerId) {
    const { data: prof } = await supabase.from("profiles").select("email, full_name").eq("id", ownerId).maybeSingle();
    ownerEmail = (prof?.full_name as string) || (prof?.email as string) || null;
  }

  return (
    <AdminAppClient
      myUserId={user.id}
      myEmail={user.email ?? ""}
      initialOwnerId={ownerId}
      ownerEmail={ownerEmail}
      initialDefaultPct={Number(config?.default_commission_pct ?? 30)}
      initialNudges={nudges}
      leaderboard={(leaderboard ?? []) as RepLeaderRow[]}
      team={teamSummary ?? { team_mrr_cents: 0, team_commission_cents: 0, apps_created: 0, apps_sold: 0, active_reps: 0 }}
    />
  );
}
