import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";
import { sharedCookieDomain, sharedCookieOptions } from "./cookie-domain";

/**
 * Refreshes the Supabase auth cookie on every request, so sessions persist
 * correctly.
 *
 * CP-84 — refresh-token storm fix (Jul 25 2026 incident).
 * ---------------------------------------------------------------------
 * Symptom: 54k auth requests/hour, Vercel logs full of
 *   `AuthApiError: Invalid Refresh Token: Already Used`
 *   (code: refresh_token_already_used)
 * and Supabase auth logs full of `429: Request rate limit reached` on
 * POST /token, which locked real people out of signing in.
 *
 * Two causes, both fixed here:
 *
 *   1. LEGACY HOST-ONLY COOKIE (the big one). Before CP-81 the auth
 *      cookie was host-only (`www.atlas-engine.app`). CP-81 re-scoped it
 *      to the parent domain (`.atlas-en