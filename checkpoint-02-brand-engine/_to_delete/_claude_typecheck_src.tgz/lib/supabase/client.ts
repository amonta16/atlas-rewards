// Browser-side Supabase client. Used inside Client Components.
"use client";

import { createBrowserClient } from "@supabase/ssr";
import { sharedCookieOptions } from "./cookie-domain";

export function createClient() {
  // CP-81: parent-domain cookie so one login covers every business
  //