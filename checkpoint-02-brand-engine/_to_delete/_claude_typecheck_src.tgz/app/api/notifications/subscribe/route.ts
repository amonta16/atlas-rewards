/**
 * POST /api/notifications/subscribe — CP-32 / CP-42
 *
 * Persists a browser PushSubscription on the signed-in user. Body:
 *   { business_id: uuid | null, subscription: { endpoint, keys: { p256dh, auth } } }
 *
 * CP-42 rewrite: switched from `supabase.rpc("upsert_push_subscription")` to
 * a direct admin-client upsert. The RPC was failing silently because
 * `auth.uid()` inside the RPC came back null on customer subdomains —
 * the session cookie set on `dermis.atlas-engine.app` didn't always
 * reach the Postgres function context. The admin client bypasses RLS
 * entirely and we pass the user_id we already verified in this route.
 */
import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { rateLimit, clientKey, tooMany } from "@/lib/rate-limit";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function POST(req: Request) {
  // CP-44: cap subscription churn per IP.
  const rl = await rateLimit(clientKey(req, "subscribe"), 20, 60);
  if (!rl.ok) return tooMany(rl.retryAfter);

  // 1. Verify the caller via session-bound client (reads cookies)
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    console.log("[subscribe] no auth — rejecting");
    return NextResponse.json({ error: "not authenticated" }, { status: 401 });
  }

  // 2. Parse body
  let payload: any;
  try { payload = await req.json(); }
  catch (e) {
    console.log("[subscribe] bad json");
    return NextResponse.json({ error: "bad json" }, { status: 400 });
  }

  // ---- CP-77: NATIVE branch — Capacitor app registering an FCM token.
  // Body: { platform: "android"|"ios", token, business_id? | business_slug? }
  // Stored with endpoint = "fcm:<token>" so unique(user_id, endpoint) and
  // the CP-51 business-scoped fan-out work unchanged.
  if (payload.platform === "android" || payload.platform === "ios") {
    const token = typeof payload.token === "string" ? payload.token.trim() : "";
    if (token.length < 20 || token.length > 4096) {
      return NextResponse.json({ error: "invalid token" }, { status: 400 });
    }
    const admin2 = createAdminClient();
    let nativeBusinessId: string | null = payload.business_id ?? null;
    if (!nativeBusinessId && typeof payload.business_slug === "string") {
      const { data: biz } = await admin2
        .from("businesses").select("id").eq("slug", payload.business_slug).maybeSingle();
      nativeBusinessId = biz?.id ?? null;
    }
    const { error: nativeErr } = await admin2
      .from("push_subscriptions")
      .upsert(
        {
          user_id: user.id,
          business_id: nativeBusinessId,
          endpoint: `fcm:${token}`,
          p256dh: null,
          auth: null,
          platform: payload.platform,
          last_seen_at: new Date().toISOString(),
        },
        { onConflict: "user_id,endpoint" },
      );
    if (nativeErr) {
      console.log("[subscribe] native upsert failed:", nativeErr.message, nativeErr.code);
      return NextResponse.json({ error: "upsert_failed", message: nativeErr.message }, { status: 400 });
    }
    console.log("[subscribe] saved native token 