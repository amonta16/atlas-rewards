"use client";
import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  // CP-58: base corner radius reads the per-business --atlas-btn-radius token
  // (set by designVars() on the customer-app surface). Falls back to 0.375rem
  // (== rounded-md) everywhere the var isn't defined — e.g. the agency portal —
  // so nothing outside a customer app changes.
  // CP-67: --atlas-cta-glow adds a per-business brand glow behind primary
  // CTAs on the customer surface. Falls back to no shadow everywhere else.
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-[var(--atlas-btn-radius,0.375rem)] shadow-[var(--atlas-cta-glow,0_0_#0000)] text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        default: "bg-brand-primary text-white hover:opacity-90",
        outline: "border border-input bg-background hover:bg-muted",
        ghost: "hover:bg-muted",
        destructive: "bg-red-600 text-white hover:bg-red-700",
        secondary: "bg-muted text-foreground hover:bg-muted/80",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-8 px-3 text-xs",
        lg: "h-12 px-6 text-base",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: { variant: "default", size: "default" },
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Sl