"use client";
/**
 * ImageLibraryPicker — CP-64
 *
 * The "stop googling stock photos" modal. Browses the pre-curated
 * `image_library` (seeded per industry × hero/reward/offer) and returns the
 * picked image's public URL — the same shape ImageUploader produces, so the
 * two are interchangeable everywhere an image gets set in the builder.
 *
 * • Industry chips across the top (defaults to the business's niche)
 * • Hero / Rewards / Offers tabs (defaults to the slot being edited)
 * • Search box filters by title + tags
 * • Hover an image → "Use photo", or hide a dud from the library forever
 *
 * CP-64.1: builders can UPLOAD their own photos into the shared library —
 * filed under a niche + section, tagged, searchable, and reusable in every
 * future demo app. Admins and VAs can add (RLS-enforced); only admins hide.
 */
import { useEffect, useMemo, useRef, useState } from "react";
import { Check, EyeOff, ImageIcon, Loader2, Search, Upload, X } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  LIBRARY_CATEGORIES,
  LIBRARY_INDUSTRY_LABELS,
  libraryIndustryLabel,
  type LibraryCategory,
  type LibraryImage,
} from "@/lib/image-library";

const NEW_NICHE = "__new__";

export function ImageLibraryPicker({
  defaultIndustry,
  defaultCategory,
  onSelect,
  onClose,
}: {
  /** Library industry slug to open on (e.g. "medspa"). Unknown/null → first available. */
  defaultIndustry?: string | null;
  /** Which tab to open on — pass the slot being edited. */
  defaultCategory?: LibraryCategory;
  onSelect: (url: string) => void;
  onClose: () => void;
}) {
  const [rows, setRows] = useState<LibraryImage[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  const [industry, setIndustry] = useState<string | null>(defaultIndustry ?? null);
  const [category, setCategory] = useState<LibraryCategory>(defaultCategory ?? "hero");
  const [q, setQ] = useState("");

  // ---- CP-64.1: upload panel state ----
  const [showUpload, setShowUpload] = useState(false);
  const [upIndustry, setUpIndustry] = useState<string>(defaultIndustry ?? "medspa");
  const [upNewNiche, setUpNewNiche] = useState("");
  const [upCategory, setUpCategory] = useState<LibraryCategory>(defaultCategory ?? "hero");
  const [upTags, setUpTags] = useState("");
  const [upBusy, setUpBusy] = useState(false);
  const [upMsg, setUpMsg] = useState<string | null>(null);
  const upFileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    (async () => {
      const supabase = createClient();
      const { data, error } = await supabase
        .from("image_library")
        .select("*")
        .eq("is_active", true)
        .order("sort_order")
        .order("created_at");
      if (error) {
        setErr(
          /relation .* does not exist/i.test(error.message)
            ? "The image library isn't set up yet. Run checkpoint-64-image-library/cp64_image_library.sql, then seed it with scripts/seed-image-library.mjs."
            : error.message
        );
      } else {
        setRows((data ?? []) as LibraryImage[]);
      }
      setLoading(false);
    })();
  }, []);

  /** Industries that actually have images, in a stable order. */
  const industries = useMemo(() => {
    const set = new Set(rows.map((r) => r.industry));
    return [...set].sort((a, b) => libraryIndustryLabel(a).localeCompare(libraryIndustryLabel(b)));
  }, [rows]);

  /** Upload destination choices: every known label + every niche with images. */
  const uploadIndustries = useMemo(() => {
    const set = new Set([...Object.keys(LIBRARY_INDUSTRY_LABELS), ...industries]);
    return [...set].sort((a, b) => libraryIndustryLabel(a).localeCompare(libraryIndustryLabel(b)));
  }, [industries]);

  // Snap to a real industry once rows load (default may be null or empty).
  useEffect(() => {
    if (!loading && industries.length && (!industry || !industries.includes(industry))) {
      setIndustry(industries[0]);
    }
  }, [loading, industries, industry]);

  const visible = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return rows.filter(
      (r) =>
        r.industry === industry &&
        r.category === category &&
        (!needle ||
          r.title.toLowerCase().includes(needle) ||
          r.tags.some((t) => t.includes(needle)))
    );
  }, [rows, industry, category, q]);

  async function hideImage(img: LibraryImage) {
    // Soft-hide a dud (agency admins only — RLS enforces it server-side).
    setRows((rs) => rs.filter((r) => r.id !== img.id));
    const supabase = createClient();
    const { error } = await supabase
      .from("image_library")
      .update({ is_active: false })
      .eq("id", img.id);
    if (error) {
      setRows((rs) => [...rs, img]); // roll back
      setErr(`Couldn't hide that image: ${error.message}`);
    }
  }

  // ---- CP-64.1: upload handler ----
  async function handleUpload(files: FileList) {
    const targetIndustry =
      upIndustry === NEW_NICHE
        ? upNewNiche.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "")
        : upIndustry;
    if (!targetIndustry) {
      setUpMsg("Give the new niche a name first.");
      return;
    }
    setUpBusy(true);
    setUpMsg(null);
    const supabase = createClient();
    const tags = [
      ...new Set([
        targetIndustry,
        upCategory,
        "custom",
        ...upTags.split(",").map((t) => t.trim().toLowerCase()).filter(Boolean),
      ]),
    ];
    let ok = 0;
    let firstErr: string | null = null;

    for (const file of Array.from(files)) {
      try {
        const ext = (file.name.split(".").pop() ?? "jpg").toLowerCase();
        const safe = file.name
          .replace(/\.[^.]+$/, "")
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, "-")
          .replace(/^-+|-+$/g, "")
          .slice(0, 40) || "photo";
        const storagePath = `${targetIndustry}/${upCategory}/upload-${Date.now()}-${safe}.${ext}`;
        const { error: upErr } = await supabase.storage
          .from("image-library")
          .upload(storagePath, file, { contentType: file.type || "image/jpeg", upsert: false });
        if (upErr) throw new Error(upErr.message);
        const { data: { publicUrl } } = supabase.storage.from("image-library").getPublicUrl(storagePath);
        const title = safe.replace(/-/g, " ").replace(/^\w/, (c) => c.toUpperCase());
        const { data: inserted, error: dbErr } = await supabase
          .from("image_library")
          .insert({
            industry: targetIndustry,
            category: upCategory,
            title,
            tags,
            storage_path: storagePath,
            public_url: publicUrl,
            credit: "Team upload",
            is_active: true,
            sort_order: 0,
          })
          .select()
          .single();
        if (dbErr) throw new Error(dbErr.message);
        if (inserted) setRows((rs) => [inserted as LibraryImage, ...rs]);
        ok++;
      } catch (e: any) {
        firstErr = firstErr ?? (e?.message || "upload failed");
      }
    }

    setUpBusy(false);
    if (ok > 0) {
      // Jump the browser to where the new photos landed.
      setIndustry(targetIndustry);
      setCategory(upCategory);
      setQ("");
      setShowUpload(false);
      setUpTags("");
      setUpNewNiche("");
    }
    setUpMsg(
      firstErr
        ? `${ok} uploaded, then hit an error: ${firstErr}${/row-level security/i.test(firstErr) ? " — run cp64_1_library_uploads.sql so admins + VAs can upload." : ""}`
        : null
    );
    if (upFileRef.current) upFileRef.current.value = "";
  }

  return (
    <div className="fixed inset-0 z-[70] bg-black/60 flex items-center justify-center p-4">
      <div className="w-full max-w-3xl max-h-[85vh] bg-white rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* header */}
        <div className="px-5 pt-5 pb-4 border-b flex items-start justify-between gap-3">
          <div>
            <h2 className="font-extrabold text-lg leading-tight">Image library</h2>
            <p className="text-xs text-zinc-500 mt-0.5">
              Pre-curated demo photos — pick one and it drops straight in.
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <Button
              size="sm"
              type="button"
              variant={showUpload ? "default" : "outline"}
              className="h-8 text-xs font-semibold"
              onClick={() => { setShowUpload(v => !v); setUpMsg(null); }}
            >
              <Upload className="h-3.5 w-3.5 mr-1.5" /> Upload photos
            </Button>
            <button
              onClick={onClose}
              className="h-9 w-9 rounded-full hover:bg-zinc-100 flex items-center justify-center"
              aria-label="Close"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* CP-64.1: upload panel */}
        {showUpload && (
          <div className="px-5 py-3 border-b bg-zinc-50 space-y-2.5">
            <div className="flex flex-wrap items-center gap-2">
              <select
                className="h-8 rounded-md border border-input bg-white px-2 text-xs font-semibold"
                value={upIndustry}
                onChange={(e) => setUpIndustry(e.target.value)}
              >
                {uploadIndustries.map((slug) => (
                  <option key={slug} value={slug}>{libraryIndustryLabel(slug)}</option>
                ))}
                <option value={NEW_NICHE}>＋ New niche…</option>
              </select>
              {upIndustry === NEW_NICHE && (
                <Input
                  className="h-8 w-36 text-xs"
                  placeholder="e.g. Pet Grooming"
                  value={upNewNiche}
                  onChange={(e) => setUpNewNiche(e.target.value)}
                />
              )}
              <div className="flex rounded-lg bg-white border p