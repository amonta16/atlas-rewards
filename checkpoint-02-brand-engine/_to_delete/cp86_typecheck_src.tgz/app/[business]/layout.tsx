import { notFound } from "next/navigation";
import type { Metadata, Viewport } from "next";
import { createClient } from "@/lib/supabase/server";
import { hexToHsl } from "@/lib/utils";
import type { Business } from "@/lib/types/database";
// CP-42: cache brand into localStorage so loading.tsx files can theme.
import { BrandCacheWriter } from "@/components/ui/brand-cache-writer";
// CP-42: logo-fade splash that plays once per cold boot (and on first
// install). Replaces the prior brand-color body-paint approach.
import { PWABootSplash } from "@/components/ui/pwa-boot-splash";

export const dynamic = "force-dynamic";

/**
 * CP-37: per-business iOS PWA meta tags. WITHOUT these, iPhone users
 * who installed the PWA to their home screen would have every tap
 * bounce out to Safari instead of staying inside the standalone app.
 * The apple-mobile-web-app-capable directive is what flips that.
 *
 * We also wire apple-touch-icon to the business's logo so the home-
 * screen icon picks up THEIR brand, not Atlas's default.
 */
// CP-42: per-business theme color in a separate Viewport export.
export async function generateViewport(
  { params }: { params: { business: string } },
): Promise<Viewport> {
  const supabase = createClient();
  const { data } = await supabase
    .from("businesses").select("brand_colors").eq("slug", params.business).maybeSingle();
  const themeColor = (data?.brand_colors as { primary?: string } | null)?.primary ?? "#0a3d62";
  return {
    themeColor,
    width: "device-width",
    initialScale: 1,
  };
}

export async function generateMetadata(
  { params }: { params: { business: string } },
): Promise<Metadata> {
  const supabase = createClient();
  const { data } = await supabase
    .from("businesses")
    .select("name, logo_url, app_icon_url, brand_colors")
    .eq("slug", params.business)
    .maybeSingle();

  const name = data?.name ?? "Atlas Rewards";
  const themeColor = (data?.brand_colors as { primary?: string } | null)?.primary ?? "#0a3d62";
  const shortName = name.length > 12 ? name.slice(0, 12) : name;
  // CP-38: square icon preferred for the home-screen / apple-touch-icon.
  const iconUrl = (data as any)?.app_icon_url ?? data?.logo_url ?? null;

  return {
    title: `${name} Rewards`,
    description: `Earn points and unlock rewards at ${name}.`,
    // CP-42: themeColor moved to viewport export (Next.js 14+ deprecated it from metadata).
    appleWebApp: {
      capable: true,
      title: shortName,
      statusBarStyle: "default",
    },
    icons: iconUrl
      ? {
          icon: iconUrl,
          apple: iconUrl,
        }
      : undefined,
    other: {
      // Belt-and-suspenders: explicitly set these in case the
      // appleWebApp metadata helper doesn't emit them in every
      // Next.js version.
      "apple-mobile-web-app-capable": "yes",
      "apple-mobile-web-app-status-bar-style": "default",
      "mobile-web-app-capable": "yes",
      "format-detection": "telephone=no",
    },
  };
}

export default async function BusinessLayout({
  children,
  params,
}: { children: React.ReactNode; params: { business: string } }) {
  const supabase = createClient();

  // Resolve the business by slug. resolve_business_by_slug() is the function
  // we created in Checkpoint 1 — callable by anon users (pre-login customers).
  const { data, error } = await supabase
    .rpc("resolve_business_by_slug", { p_slug: params.business });

  if (error || !data || data.length === 0) notFound();

  const business = data[0] as unknown as Business;

  // Build the per-business CSS-variable theme
  const themeVars = `
    --brand-primary: ${hexToHsl(business.brand_colors.primary)};
    --brand-secondary: ${hexToHsl(business.brand_colors.secondary)};
    --brand-accent: ${hexToHsl(business.brand_colors.accent)};
  `;

  // CP-42 (round 2): replaced the brand-color body-paint approach with
  // a proper logo-fade boot splash overlay. White everywhere so the
  // splash blends seamlessly into the app behind it.
  const splashCss = `
    html, body { background-color: white; }
  `;

  return (
    <>
      <style>{`:root { ${themeVars} } ${splashCss}`}</style>
      {/* CP-42: white-background, logo-center boot splash that fades
          into the app over ~1.25s. Fires ONCE per session — every
          subsequent navigation gets the BrandedLoading route screen. */}
      <PWABootSplash
        primary={business.brand_colors.primary}
        name={business.name}
        logoUrl={business.logo_url ?? null}
      />
      {/* CP-42: store brand in localStorage so subsequent navigations
          render a THEMED loading screen (via BrandedLoading), not the
          default Atlas blue. No-op on first visit. */}
      <BrandCacheWriter
        slug={business.slug}
        primary={business.brand_colors.primary}
        name={business.name}
        logoUrl={business.logo_url ?? null}
      />
      {/* Pass business down via React context in CP 3 — for now layout is server-rendered */}
      <div data-business-slug={business.slug}>{children}</div>
    </>
  );
}
